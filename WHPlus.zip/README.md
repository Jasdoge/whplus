Detta är en chrome extension som gör det enklare att hålla koll på medlemssystemet på Webhallen.com genom att lägga till push notifikationer när:

* Du har en ny supply drop
* Du får ett nytt meddelande
* Leverans-status uppdateras

Installera manuellt: https://webkul.com/blog/how-to-install-the-unpacked-extension-in-chrome/

Kan även installeras via chrome web store (ligger dock efter på uppdateringar pga av googles sega verifieringssystem): https://chrome.google.com/webstore/detail/wh%20/ajjcgnilmephijgaogahkplailcdpndm?authuser=3


## Manual

1. Logga in på webhallen.com
2. WH+ ikonen längst uppe till höger i webbläsaren kommer sluta lysa rött efter ett tag.
3. WH+ ikonen kommer bli blå när du har nya meddelanden.
4. Du kan klicka på krysset för att ta bort en notifikation.

**Tillägget hanterar inga personuppgifter eller login-information.** När du loggat in "besöker" tillägget webhallen.com och hämtar informationen åt dig med din redan existerande session.

